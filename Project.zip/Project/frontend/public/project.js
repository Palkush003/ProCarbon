const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');

registerLink.addEventListener('click',()=>{
    wrapper.classList.add('active');
})

loginLink.addEventListener('click',()=>{
    wrapper.classList.remove('active');
})

btnPopup.addEventListener('click',()=>{
    wrapper.classList.add('active-popup');
})

iconClose.addEventListener('click',()=>{
    wrapper.classList.remove('active-popup');
})

// function openCalculatorWindow() {
//     // Open the calculator page in a new window
//     const calculatorWindow = window.open("calculator.html", "_blank", "width=600,height=400");
// }

// function openPopup(type) {
//     let content = "";

//     switch (type) {
//         case 'about':
//             content = "This is the About page content.";
//             break;
//         case 'services':
//             content = "These are our Services.";
//             break;
//         case 'contact':
//             content = "Contact us at example@example.com.";
//             break;
//         case 'home':
//             content = "Welcome to our Home page.";
//             break;
//         default:
//             content = "Content not available.";
//             break;
//     }

//     // Open a new popup window with the content
//     const popupWindow = window.open('', '_blank', 'width=400,height=300');
//     popupWindow.document.write(`<html><body>${content}</body></html>`);
//     popupWindow.document.close();
// }

function openPopup(type) {
    let content = "";

    switch (type) {
        case 'about':
            content = "This is the About page content.";
            break;
        case 'services':
            content = "These are our Services.";
            break;
        case 'contact':
            content = "Contact us at example@example.com.";
            break;
        case 'home':
            content = "Welcome to our Home page.";
            break;
        default:
            content = "Content not available.";
            break;
    }

    // Open a new popup window with the content and styling
    const popupWindow = window.open('', '_blank', 'width=400,height=300');
    popupWindow.document.write(`
        <html>
        <head>
            <link rel="stylesheet" href="popup.css">
        </head>
        <body>
            <div class="popup-content">${content}</div>
        </body>
        </html>
    `);
    popupWindow.document.close();
}

function navigateToServicePage(url) {
    window.location.href = url;
}